<?php require_once 'configs/config.php'; ?>

<header>
    <div class="container">
        <nav class="d-flex align-items-center">
            <h1 class="me-4">TaakBeheer</h1>
            <a class="me-4" href="<?php echo $base_url; ?>/index.php">Home</a>
            <a class="me-4" href="<?php echo $base_url; ?>/Create.php">Create</a>
        </nav>
    </div>
</header>